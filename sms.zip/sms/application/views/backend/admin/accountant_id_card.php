<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/aid.png"  alt="" />
	      
           
</div>