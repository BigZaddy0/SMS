<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/book.png"  alt="" />
	      
           
</div>