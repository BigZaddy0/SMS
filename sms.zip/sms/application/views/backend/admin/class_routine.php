<style type="text/css">
<!--
.style2 {color: #990000}
.style3 {font-size: 18px}
-->
</style>
<!-- <p align="center" class="style3"><strong>Disabled in Basic Version</strong></p> -->
<p align="center" class="style3"><strong><a href="http://itsourcecode.com/" target="_blank" class="style2"><u>Get</u></a> the full version for free! <u>100% Source Code</u> <a href="http://itsourcecode.com/" target="_blank"><u><span class="style2">www.itsourcecode.com</span> </u></a></strong></p>
<center>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<div align="center">
  <input type="hidden" name="cmd" value="_s-xclick">
  <input type="hidden" name="hosted_button_id" value="4BKA5ZHWXARDU">
</div>
<table>
<tr><td><input type="hidden" name="on0" value="Select Software:">Donate to us:</td></tr><tr><td> </td></tr>
</table>
<input type="hidden" name="currency_code" value="USD">
<input type="image" src="https://www.paypalobjects.com/en_GB/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal � The safer, easier way to pay online.">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>
</center>
<!-- <p><img src="uploads/images/admin/classroutine_admin.PNG" width="1043" height="626" /></p> -->
