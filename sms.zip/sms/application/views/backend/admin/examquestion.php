<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/eq.png"  alt="" />
	      
           
</div>