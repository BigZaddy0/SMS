<!-- Footer -->
<footer class="main" align="center" style="color:#FF0000"><?php echo $footer;?></footer>
	
